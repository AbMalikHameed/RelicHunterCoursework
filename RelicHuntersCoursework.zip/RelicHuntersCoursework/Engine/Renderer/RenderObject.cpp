#include "RenderObject.h"

RenderObject::RenderObject()
{

}

RenderObject::~RenderObject()
{

}
