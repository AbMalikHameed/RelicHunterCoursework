#include "ItemFactory.h"

ItemFactory::ItemFactory()
{
}

ItemFactory::~ItemFactory()
{
}

void ItemFactory::Initialise()
{
}

Item * ItemFactory::make_item(int pint)
{
	return nullptr;
}
