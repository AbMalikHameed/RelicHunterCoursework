#include "Enemy.h"
Enemy::Enemy()
{
	
}

Enemy::~Enemy()
{
	
}

void Enemy::GetPosition(int& x, int& y)
{
	x = m_animated_sprite_.getPosition().x;
	y = m_animated_sprite_.getPosition().y;
}

void Enemy::CheckBounds()
{
}
	
void Enemy::Initialise()
{
	
}

void Enemy::Update()
{
	
}




