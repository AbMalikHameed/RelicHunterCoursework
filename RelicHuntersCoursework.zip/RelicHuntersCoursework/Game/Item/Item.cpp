#include "Item.h"

Item::Item()
{
}

Item::~Item()
{
}
void Item::Initialise()
{
	
}

void Item::Update()
{
	
}

void Item::GetPosition(int& x, int& y)
{
	
}
