#include "Game\Game.h"

int main()
{
	Game game;

	game.Initialise();

	game.Run();

	return 0;
}
