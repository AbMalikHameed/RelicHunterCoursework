# RelicHuntersCoursework
Coursework done for University. We were given permission to use the Relic Hunter art assets for the game. I had the role of the Enemies and Items developer and programmed Enemy_2, the health pickup as well as the item factory for the game.

# Group
Our Group consisted of 5 roles:

Core Developer (Menu, Level and GameStates, UI and Final Migration)

Enemy & Pickup Developer (Enemy Creation and Logic, Item Factory and Item creation) x2

Level Developer (Tilemap Creation, and World Collisions)

Player Developer (Player Movement, Interaction and Weapons)
